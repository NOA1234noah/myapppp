
import './App.css';
import ALL from './commponents/all_hw';


function App() {
  return (
    <div className="container">
      <ALL />
    </div>
  );
}

export default App;
